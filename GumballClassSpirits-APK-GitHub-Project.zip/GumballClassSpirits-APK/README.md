# Gumball Class Spirits – Android WebView wrapper

This project creates an Android APK that opens the browser-hosted game in a fullscreen WebView. It does **not** contain or extract the original game files.

## Build the APK with GitHub Actions

1. Create a new GitHub repository.
2. Upload all files and folders from this project.
3. Open the **Actions** tab and enable workflows if GitHub asks.
4. Run **Build Android APK** (or push to `main`).
5. Open the completed workflow run and download the artifact named `Gumball-Class-Spirits-APK`.
6. Extract the artifact ZIP; install `app-debug.apk` on your Android device.

## Game URL

The app currently opens:

`https://www.numuki.com/game/class-spirits/`

If that site changes or blocks WebView, edit `GAME_URL` in `MainActivity.java` to a game page you are authorized to use.

## Important

- Internet is required because the game is streamed from its website.
- This is a WebView wrapper, not an offline APK.
- The game and its characters/assets may be protected by copyright. This template does not grant permission to redistribute them.
